package com.cg.tms.ui;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.InvalidDescriptionException;
import com.cg.tms.exception.InvalidPriorityException;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI 
{
	public static void main(String args[])
	{
		
		TicketService service = new TicketServiceImpl();
		
		Scanner scanner = new Scanner(System.in);
		
		TicketBean ticket = null; 
		TicketCategory cat = null;
		LocalDateTime date = null;
		List<TicketCategory> list =new ArrayList<>();
		
		
		while(true)
		{
			System.out.println("=============================================");
			System.out.println("Welcome to ITIMD Help Desk");
			System.out.println("=============================================");
			System.out.println("1. Raise a ticket  2. Exit from the system");
			System.out.println("=============================================");
		
			int choice = scanner.nextInt();
		
		switch(choice)
		{
			case 1:	int ticketNo = (int)(Math.random()*1000);
					
					System.out.println("Select Ticket Category from below list");
					System.out.println("1. Software Installation");
					System.out.println("2. Mailbox Creation");
					System.out.println("3. MailBox Issues");
					System.out.println("===================================");
					System.out.print("Enter Option: ");
					int option = scanner.nextInt();
					
					System.out.println("===================================");
					list = service.listTicketCategory();
					
					
					if(option==1)
					{
						cat = list.get(0);
					}
					else if(option==2)
					{
						cat= list.get(1);
					}
					else if(option ==3)
					{
						cat=list.get(2);
					}
					else 
					{
						System.err.println("Invalid Option");
						System.out.println();
						break;
					}
					System.out.println("Enter Description Related To Issue");
					String description = scanner.nextLine();
					description+=scanner.nextLine();
					try
					{
						service.validateDescription(description);
					}
					catch(InvalidDescriptionException e)
					{
						System.err.println(e.getMessage());
						System.out.println();
						break;
					}
					System.out.println("Enter Priority i.e. low medium or high");
					String priority = scanner.next();
					try
					{
						service.validatePriority(priority);
					}
					catch(InvalidPriorityException e)
					{
						System.err.println(e.getMessage());
						System.out.println();
						break;
					}
					String ticketStatus = "new";
					
					date=LocalDateTime.now(); 
					String itimdComments = "Ticket Number "+ticketNo+" logged successfully at "+date;
					
					ticket = new TicketBean(String.valueOf(ticketNo),cat,description,priority,ticketStatus,itimdComments);
					service.raiseNewTicket(ticket);
					System.out.println("===================================");
					System.out.println(itimdComments);
					break;
			case 2: System.out.println("Thank You For Using The Application");
					System.exit(0);
		}
		
	}
	}
}
