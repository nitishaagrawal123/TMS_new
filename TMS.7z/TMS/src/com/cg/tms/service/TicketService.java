package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.InvalidDescriptionException;
import com.cg.tms.exception.InvalidPriorityException;

public interface TicketService 	
{
	boolean raiseNewTicket(TicketBean ticketBean);
	List<TicketCategory> listTicketCategory();
	void validateDescription(String description) throws InvalidDescriptionException;
	void validatePriority(String priority) throws InvalidPriorityException;
}
