package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDao;
import com.cg.tms.dao.TicketDaoImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.InvalidDescriptionException;
import com.cg.tms.exception.InvalidPriorityException;

public class TicketServiceImpl implements TicketService 
{
	TicketDao tickDao = null;
	

	public boolean raiseNewTicket(TicketBean ticketBean)
	{
		tickDao = new TicketDaoImpl();
		return tickDao.raiseNewTicket(ticketBean);
	}

	@Override
	public List<TicketCategory> listTicketCategory()
	{
		tickDao = new TicketDaoImpl();
		return tickDao.listTicketCategory();
	}

	@Override
	public void validateDescription(String description) throws InvalidDescriptionException 
	{
		if(description == null)
		{
			throw new InvalidDescriptionException();
		}
	}

	@Override
	public void validatePriority(String priority) throws InvalidPriorityException 
	{
		if(!(priority.equals("low") || priority.equals("medium") || priority.equals("high")))
		{
			throw new InvalidPriorityException();
		}
		
	}

	
	
}
