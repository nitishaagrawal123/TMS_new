package com.cg.tms.exception;

public class InvalidPriorityException extends Exception
{
	public InvalidPriorityException() 
	{
		super("Priority should be low, medium or high");
	}
}
