package com.cg.tms.exception;

public class InvalidDescriptionException extends Exception
{
	public InvalidDescriptionException()
	{
		super("Invalid Product Description");
	}
}