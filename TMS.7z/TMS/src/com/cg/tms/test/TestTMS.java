package com.cg.tms.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.InvalidDescriptionException;
import com.cg.tms.exception.InvalidPriorityException;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class TestTMS
{
	TicketService ser = new TicketServiceImpl(); 
 	
	@Test(expected=InvalidDescriptionException.class)
	public void whenNoDescriptionIsEntered() throws InvalidDescriptionException
	{
		ser.validateDescription(null);
	}

	@Test(expected=InvalidPriorityException.class)
	public void whenInvalidPriorityIsEntered() throws  InvalidPriorityException
	{
		ser.validatePriority("");
	}
	
	@Test
	public void testRaiseNewTicket()
	{
		TicketBean ticketBean = new TicketBean();
		TicketCategory ticketCategory = new TicketCategory("tc001","software installation");
		ticketBean.setTicketNo("1001");
		ticketBean.setTicketCategory(ticketCategory);
		ticketBean.setTicketDescription("asdasd");
		ticketBean.setTicketPriority("low");
		ticketBean.setTicketStatus("new");
		ticketBean.setItimdComments("AERRGEYR");
		assertEquals(true,ser.raiseNewTicket(ticketBean));
	}
	
}
