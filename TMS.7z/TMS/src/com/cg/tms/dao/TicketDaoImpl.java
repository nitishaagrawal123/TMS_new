package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketDaoImpl implements TicketDao
{
	TicketCategory ticketCat = null;
	List<TicketCategory> list = new ArrayList<>();
	private static Map<String,TicketBean> tickets = new HashMap<>();
	private static Map<String,String> ticketCategory = new HashMap<>();
	public static Map<String,String> getTicketCategoryEntries()
	{
		ticketCategory.put("tc001", "software installation");
		ticketCategory.put("tc002", "mailbox creation");
		ticketCategory.put("tc003", "mailbox issues");
		return ticketCategory;
	}
	@Override
	public boolean raiseNewTicket(TicketBean ticketBean)
	{
		TicketBean result = tickets.put(ticketBean.getTicketNo(), ticketBean);
		if(result==null)
		{
			return true;
		}
		return false;
	}

	@Override
	public List<TicketCategory> listTicketCategory()
	{
		
		for(String id:getTicketCategoryEntries().keySet())
		{
				String catName = ticketCategory.get(id);
				ticketCat = new TicketCategory();
				ticketCat.setTicketCategoryId(id);
				ticketCat.setCategoryName(catName);
				list.add(ticketCat);
		}
		return list;
	}
	

}
